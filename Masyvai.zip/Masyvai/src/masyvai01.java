public class masyvai01 {


    public static void main(String[] args) {

        int[] array = {1, 2, 3};

        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }
}
