public class masyvai03 {


    public static void main(String[] args) {

        int[] array = {99, 55, 77};

        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i] + " ,vieta" + i);
        }
    }

}