public class masyvai04 {


    public static void main(String[] args) {

        int[] array = {99, 55, 77, 11, 22, 33, 44, 66, 88, 10};

        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i] + " ,vieta" + i);
        }
    }

}