import java.util.Arrays;
import java.util.Scanner;

public class masyvai06 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        int [] array = new int [6];


        for (int i = 0; i < array.length; i++) {
            System.out.println("Kokia skaiciaus reiksme? ");
            int number = rd.nextInt();
            array [i] = number;
        }

            System.out.print(Arrays.toString(array));

        rd.close();
    }

}