import java.util.Arrays;
import java.util.Scanner;

public class masyvai08 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        int [] arr1 = new int [5];

        System.out.println("Iveskite pirmojo masyvo skaiciu reiksmes:");

        for (int i = 0; i < arr1.length; i++) {
            System.out.println("Kokia skaiciaus reiksme? ");
            int number = rd.nextInt();
            arr1 [i] = number;
        }

        int [] arr2 = new int [5];

        System.out.println("Iveskite antrojo masyvo skaiciu reiksmes:");

        for (int i = 0; i < arr2.length; i++) {
            System.out.println("Kokia skaiciaus reiksme? ");
            int number = rd.nextInt();
            arr2 [i] = number;
        }

        int[] arr3 = new int [5];

        for (int i = 0; i < arr1.length; i++) {
            arr3[i] = arr1 [i] * arr2 [i];
        }

        System.out.println("Treciojo masyvo reiksmes:");
        System.out.println(Arrays.toString(arr3));

        rd.close();
    }

}