import java.util.Arrays;
import java.util.Scanner;

public class masyvai12 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int number = rd.nextInt();

        System.out.println("Iveskite kelinto masyvo elemento reiksme norite pakeisti:");
        int k = rd.nextInt();

        int min = 0;

        int max = 1000;

        max++;

        int [] arrC = new int [number];

        for (int i = 0; i < arrC.length; i++) {
            arrC [i] = random (min, max);
        }

        arrC [k-1] = 100;

        System.out.println("Masyve esancio " + k + " elemento reiksme buvo pakeista ir tapo 100.");
        System.out.print(Arrays.toString(arrC));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}