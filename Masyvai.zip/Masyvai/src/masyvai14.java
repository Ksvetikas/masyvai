import java.util.Arrays;
import java.util.Scanner;

public class masyvai14 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int number = rd.nextInt();

        System.out.println("Iveskite kuriuos masyvo elementus norite sukeisti vietomis:");
        int k = rd.nextInt();

        int m = rd.nextInt();

        int min = 0;

        int max = 1000;
        max++;

        int kElementoReiksme = 0;

        int [] arrF = new int [number];

        for (int i = 0; i < arrF.length; i++) {
            arrF [i] = random (min, max);
        }

        kElementoReiksme = arrF [k-1];

        System.out.println(Arrays.toString(arrF));

        arrF [k-1] = arrF [m-1];
        arrF [m-1] = kElementoReiksme;

        System.out.println("Masyve esancio " + k + " elemento reiksme buvo sukeista vietomis su " + m + " elemento reiksme.");
        System.out.print(Arrays.toString(arrF));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}