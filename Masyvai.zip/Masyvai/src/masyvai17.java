import java.util.Arrays;
import java.util.Scanner;

public class masyvai17 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int n = rd.nextInt();

        System.out.println("Iveskite pries kelinta masyvo elementa norite iterpti nauja masyvo elementa:");
        int k = rd.nextInt();

        int min = 0;

        int max = 1000;

        max++;

        int [] arrQ = new int [n];

        for (int i = 0; i < arrQ.length; i++) {
            arrQ [i] = metodai.random (min, max);
        }

        int [] arrY = new int [n + 1];

        for (int i = 0; i < arrQ.length; i++) {
            if ((k - 1) == i){
                arrY [i] = metodai.random(min, max);
            }else if ((k - 1) < i){
                if (i + 1 == arrQ.length){
                    arrY[i + 1] = arrQ[i];
                    arrY[i] = arrQ[i - 1];
                }else {
                    arrY[i] = arrQ[i - 1];
                }
            }else{
                arrY [i] = arrQ [i];
            }
        }
        System.out.print(Arrays.toString(arrQ));
        System.out.println();
        System.out.println("Masyve buvo iterptas elementas esantis pries " + k + " elementa jo reiksme " + arrY[k - 1]  + ".");
        System.out.print(Arrays.toString(arrY));

        rd.close();
    }

//    public static int random(int min, int max) {
//
//        return (int) ((Math.random() * (max - min)) + min);
//    }
}