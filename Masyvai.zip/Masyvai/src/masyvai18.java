import java.util.Arrays;
import java.util.Scanner;

public class masyvai18 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int n = rd.nextInt();

        int min = -1000;

        int max = 1000;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] arrT = new int [n];

        int [] naujas = new int [n];

        int j = 0;

        for (int i = 0 ; i < arrT.length; i++) {

            arrT [i] = random (min, max);
            if (arrT [i] < 0) {
                naujas [j] = arrT [i];
                j++;
            }
        }

        for (int i = 0 ; i < arrT.length; i++) {

            if (arrT [i] == 0) {
                naujas [j] = 0;
                j++;
            }
        }

        for (int i = 0 ; i < arrT.length; i++) {

            if (arrT [i] > 0) {
                naujas [j] = arrT [i];
                j++;
            }
        }


//        System.out.print(Arrays.toString(arrT));
        System.out.println();
        System.out.println("Masyve sudelioti elementai turintys neigiama reiksme po to nuline o tada teigiama.");
        System.out.print(Arrays.toString(naujas));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}