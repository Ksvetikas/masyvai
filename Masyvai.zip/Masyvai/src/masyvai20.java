import java.util.Arrays;
import java.util.Scanner;

public class masyvai20 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite skaiciu keli teisejai vertina sportininka:");
        int n = rd.nextInt();

        int min = 1;

        int max = 10;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] balai = new int [n];

        int minArrZ = 0;
        int maxArrZ = 0;
        int baluSuma = 0;
        double baluVidurkis = 0;

        for (int i = 0 ; i < balai.length; i++) {

            balai [i] = random (min, max);
            baluSuma = baluSuma + balai[i];

            if (i == 0){
                minArrZ = balai [i];
                maxArrZ = balai [i];

            }else if (minArrZ > balai [i]) {
                minArrZ = balai [i];

            }else if (maxArrZ < balai [i]) {
                maxArrZ = balai [i];
            }
        }

        baluSuma = (baluSuma - minArrZ) - maxArrZ;
        baluVidurkis = (double)baluSuma / (balai.length - 2);
        baluVidurkis = Math.round(baluVidurkis);

        System.out.println("Sportininko galutinis ivertinimas " + (int)baluVidurkis + " balai.");

        System.out.println("Visi balai: ");
        System.out.print(Arrays.toString(balai));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}