import java.util.Arrays;
import java.util.Scanner;

public class masyvai21 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek mokiniu pazymiu:");
        int n = rd.nextInt();

        int min = 1;

        int max = 10;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] pazymiai = new int [n];

        int pazymiuSuma = 0;
        double pazymiuVidurkis;
        int neislaike = 0;

        for (int i = 0 ; i < pazymiai.length; i++) {

            pazymiai [i] = random (min, max);

            if (pazymiai [i] >= 4){
                pazymiuSuma = pazymiuSuma + pazymiai [i];

            }else if (pazymiai [i] < 4) {
                neislaike++;
            }
        }

        pazymiuVidurkis = (double)pazymiuSuma / (n - neislaike);
        pazymiuVidurkis = (double) Math.round(pazymiuVidurkis * 10) / 10;

        System.out.println("Buvo ivesta " + n + " mokiniu pazymiai. " + neislaike + " is ju neislaike egzamino.");
        System.out.println("Pazangiu mokiniu vidurkis " + pazymiuVidurkis + ".");

        System.out.println("Visi pazymiai: ");
        System.out.print(Arrays.toString(pazymiai));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}