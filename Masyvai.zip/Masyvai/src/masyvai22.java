import java.util.Arrays;
import java.util.Scanner;

public class masyvai22 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek elementu sudaro skaiciu masyva:");
        int n = rd.nextInt();

        int min = -100;

        int max = 100;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] arrN = new int [n];

        int neigiamuKiekis = 0;

        for (int i = 0 ; i < arrN.length; i++) {

            arrN [i] = random (min, max);

            if (arrN [i] < 0){
                neigiamuKiekis++;
            }
        }

        if (neigiamuKiekis > 0){
            System.out.println("TAIP");
            System.out.print("Neigiami elementai:");
            for (int i = 0 ; i < arrN.length; i++) {
                if (arrN [i] < 0){
                    System.out.print(arrN [i] + ", ");
                }
            }
            System.out.println();
            System.out.println("Neigiami " + neigiamuKiekis + " elementai.");
        }else {
            System.out.println("NE");
        }

        System.out.print(Arrays.toString(arrN));
        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}