import java.util.Arrays;
import java.util.Scanner;

public class masyvai23 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek elementu sudaro skaiciu masyva:");
        int n = rd.nextInt();

        int min = -100;

        int max = 100;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] arrL = new int [n];

        int pirmasisElementas = 0;

        for (int i = 0 ; i < arrL.length; i++) {

            arrL [i] = random (min, max);
        }
        System.out.println("Nepakeistas masyvas:");
        System.out.print(Arrays.toString(arrL));

        pirmasisElementas = arrL [0];
        arrL [0] = arrL [arrL.length - 2];
        arrL [arrL.length - 2] = pirmasisElementas;

        System.out.println();
        System.out.println("Pakeistas masyvas:");
        System.out.print(Arrays.toString(arrL));
        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}