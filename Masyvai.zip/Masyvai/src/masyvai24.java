import java.util.Arrays;
import java.util.Scanner;

public class masyvai24 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek elementu sudaro skaiciu masyva:");
        int n = rd.nextInt();

        int min = -100;

        int max = 100;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] arrS = new int [n];

        System.out.print("Pirmojo neigiamo masyvo elemento nr. yra ");

        int count = 0;

        for (int i = 0 ; i < arrS.length; i++) {

            arrS [i] = random (min, max);
            if (arrS [i] < 0){
                if (count == 0){
                    System.out.print((i + 1) + ".");
                    count++;
                }
            }
        }

        System.out.println();
        System.out.println("Visas masyvas:");
        System.out.print(Arrays.toString(arrS));
        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}
